pass1 thru pass3
fail1 thru fail33
=================

Test suite from http://json.org/JSON_checker/.

If the JSON grammar and the PEGTL are working correctly, they must accept all of the `pass*.json` files and reject all of the `fail*.json` files.

Two of the failure tests are disabled since they are no longer applicable to newer JSON standards.



fail34 thru fail39
==================

Additional tests added by the PEGTL authors.
