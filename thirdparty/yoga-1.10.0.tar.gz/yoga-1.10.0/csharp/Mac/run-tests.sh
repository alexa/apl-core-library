#!/bin/sh
./csharp/Mac/Facebook.Yoga.Mac.Tests/bin/Release/Facebook.Yoga.Mac.Tests.app/Contents/MacOS/Facebook.Yoga.Mac.Tests