# Report

- [ ] I have searched [existing issues](https://github.com/facebook/yoga/issues) and this is not a duplicate

# Issues and Steps to Reproduce
***Replaces this with steps to repro your issue.***

# Expected Behavior
***Describe what you expected would happen.***

# Actual Behavior
***Describe what actually happened.***

# Link to Code
***If you have some code that maintainers can clone/test for themselves, bugs can be resolved much faster. Please paste a link here.***

***When applicable, use this [fiddle](https://jsfiddle.net/emilsjolander/jckmwztt/) to post a web repro.***
